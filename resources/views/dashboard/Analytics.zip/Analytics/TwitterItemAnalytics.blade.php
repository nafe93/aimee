<div id="AnalyticsPanel2" class="tab-pane fade">

    <fieldset class="cross-sharing-fieldset">

        <div class="form-group" >
            <div class="col-md-12">
                <legend class="cross-sharing-legend">Twitter Item Analytics</legend>
            </div>

        </div>
    </fieldset>

</div>

