<?php
/**
 * Created by PhpStorm.
 * User: alex
 * Date: 17.12.16
 * Time: 1:59
 */
    use App\Http\Controllers\JobsController;

?>

<div id="evPanel2" class="tab-pane fade in" style="overflow: hidden; height: auto;">
    <!-- Содержимое панели 2 -->
    <div>
	    <label class="cross-title">Content synchronization</label>
		<form name="form">
		    <select id="Select_from_db_content" name="Select_from_db_content" class="cs_selected cs_div_1" multiple style="height: 400px">
		        @php $i=0; @endphp
		        @foreach($data as $dat)
		            <option id ="option_from_db_content{{$i++}}" class="option_from_db_content" value="{{ $dat }}">{{ $dat }} </option>
		        @endforeach
		    </select>
		    <select id="select_to_group_content" name="select_to_group_content" class="cs_selected cs_div_2" multiple style="height: 400px;">
		    </select>
			
			<label for="sync_total_repeat">Synchronization total repeat: </label>
		   	<input type="text" name="sync_total_repeat" id="sync_total_repeat" value="1" placeholder="how many times to repeat this script">
		   	
		    <label for="run_shedule_infinitely">Run shedule infinitely?</label>
			<input type="radio" id="run_shedule_infinitely" name="run_shedule_infinitely" value="Run Shedule infinitely">

			<label for="sync_total_repeat">Synchronization period per step: </label>
		   	<!-- maks_2: todo: rename 'step length' -->
		   	<input type="text" name="sync_steps_time" id="sync_steps_time" value="5:10" placeholder="hours:minutes">
		    
		</form>
	</div>

    <pre id="out">
        
    </pre>



    <button type="button" class="cs-button sync-to-right glyphicon glyphicon-arrow-right" onclick="Add_to_group(del_content,select_to_group_content)"></button>
    <button type="button" class="cs-button sync-to-left glyphicon glyphicon-arrow-left" onclick="delete_from_group(select_to_group_content,del_content,del_content,'option_from_db_content')"></button>

    <button type="button" class="cs-button sync-center glyphicon glyphicon-refresh" onclick="save_user_sync()">Synchronize</button>
		    
</div>


<script>

        var form = document.forms[0];

        var select_to_group_content = document.getElementById("select_to_group_content");
        var del_content = document.getElementById("Select_from_db_content");

        var select = form.elements.Select_from_db_content;
        var delet = form.elements.select_to_group_content;

        //constant
        function constant(selects) {
            for (var i = 0; i < selects.options.length; i++) {
                var option = selects.options[i];
                if (option.value == "Twitter" || option.value == "FaceBook" || option.value == "Group" ||
                    option.value == "LinkedIn" || option.value == "Google" || option.value == "Instagram") {
                    option.disabled = true;
                    option.style.textAlign = "right";
                }
            }
        }

        constant(del_content);
        console.log(Add_to_group(select,select_to_group_content));

        // add to group
        function Add_to_group(selects,select_to_groups) {
            //get length of all selected elements
            var count = [];
            for (var i = 0; i < selects.options.length; i++) {
                var option = selects.options[i];
                if(option.selected == true){
                    count.push(option);
                }
            }
            // add all selected elements to group
            for(var j =0; j < count.length; j++) {
                var options = document.createElement("option");
                options = count[j];
                if(count[j].text == "group"){
                    count[j].text ="group";
                }else{
                    count[j].text = count[j].value;
                }
                select_to_groups.add(options);
                //console.log(options.index);
                count.sort();
            }
            //sort

            sortSelect(select_to_groups, 'text', 'asc');
        }

        /*
        * There we are delete and sort selected
        */

        function delete_from_group(selects,Select_from_db,dels,ids) {
            //get length of all selected elements
            var count = [];
            for (var i = 0; i < selects.options.length; i++) {
                var option = selects.options[i];
                if(option.selected == true){
                    count.push(option);
                }
            }
            // add all selected elements to group
            for(var j =0; j < count.length; j++) {
                var options = document.createElement("option");
                options = count[j];
                if(count[j].text == "group"){
                    count[j].text ="group";
                }else{
                    count[j].text = count[j].value;
                }
                dels.add(options);
                count.sort();
            }
            //sort
            sortSelect(Select_from_db, 'text', 'asc');
            //dels.addEventListener("load change",hide(dels,ids));
        }

        // sort selected
        var sortSelect = function (select, attr, order) {
            if(attr === 'text'){
                if(order === 'asc'){
                    $(select).html($(select).children('option').sort(function (x, y) {
                        return $(x).val().toUpperCase() < $(y).val().toUpperCase() ? -1 : 1;
                    }));
                    $(select).get(0).selectedIndex = 0;
                    //e.preventDefault();
                }// end asc
                if(order === 'desc'){
                    $(select).html($(select).children('option').sort(function (y, x) {
                        return $(x).val().toUpperCase() < $(y).val().toUpperCase() ? -1 : 1;
                    }));
                    $(select).get(0).selectedIndex = 0;
                    //e.preventDefault();
                }// end desc
            }
        };

        //parsing our put and send      

    </script>
