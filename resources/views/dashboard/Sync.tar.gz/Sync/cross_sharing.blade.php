<?php
/**
 * Created by PhpStorm.
 * User: alex
 * Date: 17.12.16
 * Time: 1:59
 */
    use App\Http\Controllers\JobsController;

?>

<div id="evPanel1" class="tab-pane fade in active">
    <!-- Содержимое панели 1 -->
    <fieldset style="">
<legend>Cross Sharing</legend>
    <div class="form-group">
        <div class="col-md-12">
			<label for="name-2">Content *</label>
            <!--   <textarea class="form-control" rows="3" placeholder="Hellow world at %curtime%" required></textarea> -->
            <textarea id="summernote" name ="summer_note" placeholder="Hello Summernote"></textarea>
            <script>
                $(document).ready(function() {
                    $('#summernote').summernote({

                        width: "100%",
						height: "200px"
					});
                });
            </script>
        </div>
    </div>

    <div class="form-group" >
        <div class="col-md-12">

				<label for="name-2">From Groups</label>
				<form>
					<select id="alter" name="alter" onchange="send()">
						<option value=" "></option>
						@php
							$i=0;
						@endphp
						@foreach($group_names as $name)
							<option id ="alter_option{{$i++}}" class="alter_option" value="{{ $name }}">{{ $name }} </option>
						@endforeach
					</select>
				</form>



				<form class ="cs_form">
					<div id="cs_div_1">
						<button type="button" onclick="Add_to_group(del2,alter_json)" class="cs_button"> >> </button>
						<select id="Select_from_db2" name="Select_from_db2" class="cs_selected" multiple>
							@php $i=0; @endphp
							@foreach($data as $dat)
								<option id ="option_from_db_2_{{$i++}}" class="option_from_db_2_" value="{{ $dat }}">{{ $dat }} </option>
							@endforeach
						</select>
					</div>
					<div id="cs_div_2">
						<button type="button" onclick="delete_from_group(alter_json,del2,del2,(options2))" class="cs_button"> << </button>
						<select id="alter_json" name="alter_json" class="cs_selected" multiple></select>
					</div>
				</form>
				
			<form>
				<button type="button" onclick="" class="cs_button"> Cross sharing </button>
			</form>

        </div>
	</div>
</fieldset>

	

</div>


 <script>

        var form = document.forms[0];

        var select_to_group = document.getElementById("select_to_group");
        var del = document.getElementById("Select_from_db");
        var del2 = document.getElementById("Select_from_db2");
        var alter_json = document.getElementById("alter_json");

        var select = form.elements.Select_from_db;
        var select2 = form.elements.Select_from_db2;
        var delet = form.elements.select_to_group;

        var options2 = 'option_from_db_2_' ;
        var options3 = 'option_from_db_3_' ;
        //constant
        function constant(selects) {
            for (var i = 0; i < selects.options.length; i++) {
                var option = selects.options[i];
                if (option.value == "Twitter" || option.value == "FaceBook" || option.value == "Group" ||
                    option.value == "LinkedIn" || option.value == "Google" || option.value == "Instagram") {
                    option.disabled = true;
                    option.style.textAlign = "right";
                }
            }
        }

        constant(select);
        constant(del2);

        // hide all before \\
    //    function hide(selects,option) {
    //        for(var k = 0 ; k< selects.options.length; k++) {
    //            var old_option = document.getElementById(option + k);
    //            var old_str = old_option.value.split("\\\\").pop();
    //            if(old_str != 'undefined'){
    //                old_option.text = old_str;
    //                //console.log(old_option.value);
    //            }
    //            else{
    //                old_option.text = old_str.value;
    //                //console.log(old_option.value);
    //            }
    //        }
    //    }

        // hide key in table

        //    del.addEventListener("load change",hide(select,"option_from_db"));
        //    del2.addEventListener("load change",hide(del2,"option_from_db_2_"));

        // add to group
        function Add_to_group(selects,select_to_groups) {
            //get length of all selected elements
            var count = [];
            for (var i = 0; i < selects.options.length; i++) {
                var option = selects.options[i];
                if(option.selected == true){
                    count.push(option);
                }
            }
            // add all selected elements to group
            for(var j =0; j < count.length; j++) {
                var options = document.createElement("option");
                options = count[j];
                if(count[j].text == "group"){
                    count[j].text ="group";
                }else{
                    count[j].text = count[j].value;
                }
                select_to_groups.add(options);
                //console.log(options.index);
                count.sort();
            }
            //sort

            sortSelect(select_to_group, 'text', 'asc');
        }

        /*
        * There we are delete and sort selected
        */

        function delete_from_group(selects,Select_from_db,dels,ids) {
            //get length of all selected elements
            var count = [];
            for (var i = 0; i < selects.options.length; i++) {
                var option = selects.options[i];
                if(option.selected == true){
                    count.push(option);
                }
            }
            // add all selected elements to group
            for(var j =0; j < count.length; j++) {
                var options = document.createElement("option");
                options = count[j];
                if(count[j].text == "group"){
                    count[j].text ="group";
                }else{
                    count[j].text = count[j].value;
                }
                dels.add(options);
                count.sort();
            }
            //sort
            sortSelect(Select_from_db, 'text', 'asc');
            //dels.addEventListener("load change",hide(dels,ids));
        }

        // sort selected
        var sortSelect = function (select, attr, order) {
            if(attr === 'text'){
                if(order === 'asc'){
                    $(select).html($(select).children('option').sort(function (x, y) {
                        return $(x).val().toUpperCase() < $(y).val().toUpperCase() ? -1 : 1;
                    }));
                    $(select).get(0).selectedIndex = 0;
                    //e.preventDefault();
                }// end asc
                if(order === 'desc'){
                    $(select).html($(select).children('option').sort(function (y, x) {
                        return $(x).val().toUpperCase() < $(y).val().toUpperCase() ? -1 : 1;
                    }));
                    $(select).get(0).selectedIndex = 0;
                    //e.preventDefault();
                }// end desc
            }
        };

        //parsing our put and send

        function parsing() {
            var json_key = [];
            for (var i = 0; i < delet.options.length; i++) {
                var options = delet.options[i];

                /*
                 * Here parsing option value;
                 */
                // get key value
                var str_key = options.value.split("\\\\");
                var buff_key = str_key[0];

                //delete name from str
                var str = options.value.split("Name: ");
                var string_buff = str[1];
                //console.log(string_buff);

                // get name value
                var name_buff = string_buff.substring(0, string_buff.indexOf(' ID'));
                if (buff_key == 'Twitter') {
                    name_buff = string_buff;
                }

                // get id value
                var id = string_buff.split("ID: ");
                var id_buff = id[1];
                id = id_buff;

                //add and convert array to json
                json_key.push({"key": buff_key, "name": name_buff, "id": id_buff});
            }
            console.log(JSON.stringify(json_key));
            var group_name = $("#group_name").val();

            /*
             * send file to db
             */

            $.ajax({
                url: '/cross-sharing-creat_group',
                type: 'GET',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                dataType: 'html',
                data: {param1: JSON.stringify(json_key),group_name:group_name}
            })
                .done(function(data) {
                    console.log("success");
                })
                .fail(function(data) {
                    console.log("error");
                    console.log(data);
                })
                .success(function(data) {
                    $("#alter").append($("<option></option>").attr("value",data).text(group_name));
                    //$("#alter_json").append($("<option></option>").attr("value",data).text(JSON.stringify(json_key)));
                    var $options = $("#select_to_group > option").clone();
                    $('#alter_json').append($options);
                    $('#alter_json').append($options);
                    // then we do reload
                })
                .always(function(data) {
                    console.log("complete");
                })
        }
        //end parsing and send
        
        function send(){
            var alter = $("#alter option:selected").val();

            if(alter != "") {
                //console.log(alter);
                $.ajax({
                    url: '/cross-sharing-select_groups',
                    type: 'GET',
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    dataType: 'html',
                    data: {alters: alter}
                })
                    .done(function(data) {
                        console.log("success");
                    })
                    .fail(function(data) {
                        console.log("error");
                        console.log(data);
                    })
                    .success(function(data) {
                        console.log(data);
                        // delete options from select
                        while (alter_json.firstChild) {
                            alter_json.removeChild(alter_json.firstChild);
                        }

                        var json = JSON.parse(data);

                        // visible all options in select
                        for(var k = 0; k < del2.length; k++){
                            del2[k].style.visibility = "visible";
                            del2[k].style.display = "block";
                        }
                        // create options and hidden
                        for (var i = 0; i < json.length; i++) {
                            var counter = json[i];
                            counter = counter.key + "\\\\Name: " + counter.name + " ID: " + counter.id;

                            //create table from select1
                            var x = document.createElement("OPTION");
                            x.setAttribute("value", counter);
                            x.setAttribute("id", "option_from_db_3_"+i);
                            var t = document.createTextNode(counter);
                            x.appendChild(t);
                            document.getElementById("alter_json").appendChild(x);
                            // hidden options if founded
                            for(var j = 0; j < del2.length; j++){
                                if(del2[j].value == counter)
                                {
                                    del2[j].style.visibility = "hidden";
                                    del2[j].style.display = "none";
                                }
                            }
                        }
                    })
                    .always(function(data) {
                        console.log("complete");
                    })
            }
        }

    </script>
