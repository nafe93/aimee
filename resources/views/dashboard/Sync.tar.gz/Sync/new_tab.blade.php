<?php
/**
 * Created by PhpStorm.
 * User: alex
 * Date: 17.12.16
 * Time: 1:59
 */
    use App\Http\Controllers\JobsController;

?>
<div id="evPanel3" class="tab-pane fade in" style="overflow: hidden; height: auto;">

<h3>Now empty</h3>

</div>