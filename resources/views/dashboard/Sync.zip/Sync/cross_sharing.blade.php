<style>
    .thumb {
        height: 75px;
        border: 1px solid #000;
        margin: 10px 5px 0 0;
        position: relative;
        left:25px;
    }
</style>

{{ csrf_field() }}

<div id="evPanel1" class="tab-pane fade in active">

<fieldset style="">
<legend>Cross Sharing</legend>
    <div class="form-group">
        <div class="col-md-12">
            <label for="name-2">Title *</label>
            <input type="text" id="cs_title">
            <label for="name-2">Content *</label>
            <label style="color: red; float: right" for="name-2">Attention : only the first 140 characters will be sent to twitter.</label>
            <!--   <textarea class="form-control" rows="3" placeholder="Hellow world at %curtime%" required></textarea> -->
            <textarea id="summernote" name ="summer_note" placeholder="Hello Summernote"></textarea>
            <script>
                $(document).ready(function() {
                    $('#summernote').summernote({

                        width: "100%",
                        height: "200px"
                    });
                });
            </script>
        </div>
    </div>

    <div class="form-group" >
        <div class="col-md-12">
            <label for="name-2">Images</label>
            <input style="display: none; visibility: hidden;" type="file" id="files" name="files[]" value="Select" multiple />
            <button type="button" class="cs_img" id="cs_img" onclick="$('#files').trigger('click');">Select images</button>
            <button type="button" class="cs_img" id="cs_img_del" onclick="cs_remove_img()">Remove images</button>
            <button type="button" class="cs_img" id="cs_img_del" onclick="cs_remove_all_img()">Remove All</button>
            <input type="checkbox" style="" id="single_post" onclick="single()">
            <label for="name-2" id="lab_single">POST AS SINGLE FOR FACEBOOK</label>
            <output id="list"></output>

        </div>
    </div>


    <div class="form-group" >
        <div class="col-md-12">
                <br/>
                <label for="name-2">From Groups</label>
                <form>
                    <select id="alter" name="alter">
                        <option value=" "></option>
                        @php
                            $i=0;
                        @endphp
                        @foreach($group_names as $name)
                            <option id ="alter_option{{$i++}}" class="alter_option" value="{{ $name }}">{{ $name }} </option>
                        @endforeach
                    </select>
                    <input type="button" value="ADD" class="cs_send" onclick="send()">
                </form>

                <label for="name-2">From Social list</label>
                <form>
                    <select id="choice_social">
                        <option>  </option>
                        <option> Twitter </option>
                        <option> FaceBook </option>
                        <option> Instagram </option>
                        <option> LinkedIn </option>
                        <option> Google </option>
                    </select>
                </form>

                <form class ="cs_form">
                    <div id="cs_div_1">
                        <label for="name-2">From account</label>
                        <button type="button" onclick="Add_to_group(del2,alter_json)" class="cs_button"> >> </button>
                        <select id="Select_from_db2" name="Select_from_db2" class="cs_selected" multiple>
                            {{--@php $i=0; @endphp--}}
                            {{--@foreach($data as $dat)--}}
                                {{--<option id ="option_from_db_2_{{$i++}}" class="option_from_db_2_" value="{{ $dat }}">{{ $dat }} </option>--}}
                            {{--@endforeach--}}
                        </select>
                    </div>
                    <div id="cs_div_2">
                        <label for="name-2">To</label>
                        <button type="button" onclick="delete_from_group(alter_json,del2,del2,(options2))" class="cs_button"> << </button>
                        <select id="alter_json" name="alter_json" class="cs_selected" multiple></select>
                    </div>
                </form>
            <form>
                <button type="button" onclick="sendNow()" class="cs_button"> Cross Sharing </button>
            </form>

        </div>
    </div>
</fieldset>

</div>

<script>
    var images_twitter = [];
    var images = [];
    function handleFileSelect(evt) {
        var files = evt.target.files; // FileList object

        // Loop through the FileList and render image files as thumbnails.
        for (var i = 0, f; f = files[i]; i++) {

            // Only process image files.
            if (!f.type.match('image.*')) {
                continue;
            }

            var reader = new FileReader();

            // Closure to capture the file information.
            reader.onload = (function(theFile) {
                return function(e) {
                    // Render thumbnail.
                    var span = document.createElement('span');
                    span.innerHTML = ['<img class="thumb" src="', e.target.result,
                        '" title="', escape(theFile.name), '"/>'].join('');
                    document.getElementById('list').insertBefore(span, null);
                    //for All
                    var buff_src = e.target.result;
                    images.push(buff_src);
                    //for Twitter
                    var buff_src_twitter = e.target.result;
                    buff_src_twitter = buff_src_twitter.split(',');
                    //console.log(buff_src_twitter[1]);
                    images_twitter.push(buff_src_twitter[1]);

                };
            })(f);

            // Read in the image file as a data URL.
            reader.readAsDataURL(f);
        }
        console.log(images_twitter);
    }

    document.getElementById('files').addEventListener('change', handleFileSelect, false);

    function single() {
        if($('#single_post').is(':checked')){
            var keys = 1;
        }
        else{
            keys = 0;
        }
        console.log(keys);
        return keys;
    }
    function cs_remove_img(){
        var img = $('#list').find(".thumb:first-child");
        img[0] = img[0].remove();
        images_twitter.splice(0,1);
        images.splice(0, 1);
        console.log(images_twitter);
    }
    function cs_remove_all_img() {
        $('#list').empty(".thumb"); //this is to remove all
        images =[];
        images_twitter = [];

    }
</script>

<script>

    var form = document.forms[0];

    var select_to_group = document.getElementById("select_to_group");
    var del = document.getElementById("Select_from_db");
    var del2 = document.getElementById("Select_from_db2");
    var alter_json = document.getElementById("alter_json");
    var choice_social = document.getElementById("choice_social");

    var select = form.elements.Select_from_db;
    var select2 = form.elements.Select_from_db2;
    var delet = form.elements.select_to_group;

    var options2 = 'option_from_db_2_' ;
    var options3 = 'option_from_db_3_' ;

    //hide all options
    function hidden(selects) {
        for (var i = 0; i < selects.options.length; i++) {
            var option = selects.options[i];
            option.style.display = "none";
        }
    }
    // get all options again
    function get_again() {
        var choice_socials = $("#choice_social option:selected").val();

        if(choice_socials != "") {
            //console.log(alter);
            $.ajax({
                url: '/cross-sharing-get_all',
                type: 'GET',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                dataType: 'html',
                data: {social: choice_socials}
            })
                .done(function(data) {
                    console.log("success");
                })
                .fail(function(data) {
                    console.log("error");
                    console.log(data);
                })
                .success(function(data) {

                    var d = data.replace("[","");
                    d = d.replace("]","");
                    dat = d.split(',');

                    $(del2.options).remove();


                    for(var i = 0; i <dat.length ; i++){

                        dat[i] = dat[i].replace("\\\\","");
                        dat[i] = dat[i].replace(new RegExp("\"", 'g'), '');

                        if(dat[i].indexOf("}") !== -1){
                            dat[i] = dat[i].replace("}","");
                        }
                        if(dat[i].indexOf("{") !== -1) {
                            dat[i] = dat[i].replace("{","");
                        }
                        if(dat[i].indexOf("Twitter") !== -1){
                            //dat[i] = dat[i].substring(dat[i].indexOf(":") + 1);
                            dat[i] = dat[i].substring(dat[i].indexOf("Twitter"));
                        }
                        if(dat[i].indexOf("FaceBook") !== -1){
                            dat[i] = dat[i].substring(dat[i].indexOf("FaceBook"));
                        }
                        if(dat[i].indexOf("Instagram") !== -1){
                            dat[i] = dat[i].substring(dat[i].indexOf("Instagram"));
                        }
                        if(dat[i].indexOf("LinkedIn") !== -1){
                            dat[i] = dat[i].substring(dat[i].indexOf("LinkedIn"));
                        }
                        if(dat[i].indexOf("Google") !== -1){
                           dat[i] = dat[i].substring(dat[i].indexOf("Google"));
                        }


                        if (choice_social.value == "Twitter")
                        {
                            if (dat[i].indexOf("Twitter") != -1)
                            {
                                $(del2).append($("<option></option>").attr("value",dat[i]).text(dat[i]));
                                $(del2.options).show();
                                //console.log(dat[i]);
                            }
                        }
                        if (choice_social.value == "FaceBook")
                        {
                            if (dat[i].indexOf("FaceBook") != -1)
                            {
                                $(del2).append($("<option></option>").attr("value",dat[i]).text(dat[i]));
                                $(del2.options).show();
                                //console.log(dat[i]);
                            }
                        }
                        if (choice_social.value == "Instagram")
                        {
                            if (dat[i].indexOf("Instagram") != -1)
                            {
                                $(del2).append($("<option></option>").attr("value",dat[i]).text(dat[i]));
                                $(del2.options).show();
                                //console.log(dat[i]);
                            }
                        }
                        if (choice_social.value == "LinkedIn")
                        {
                            if (dat[i].indexOf("LinkedIn") != -1)
                            {
                                $(del2).append($("<option></option>").attr("value",dat[i]).text(dat[i]));
                                $(del2.options).show();
                                //console.log(dat[i]);
                            }
                        }
                        if (choice_social.value == "Google")
                        {
                            if (dat[i].indexOf("Google") != -1)
                            {
                                $(del2).append($("<option></option>").attr("value",dat[i]).text(dat[i]));
                                $(del2.options).show();
                                //console.log(dat[i]);
                            }
                        }
                    }

                })
                .always(function(data) {
                    console.log("complete");
                })
        }
    }

   // hidden(del2);

    choice_social.addEventListener("change",function () {
        get_again();
//        hidden(del2);
        for (var i = 0; i < del2.options.length; i++) {
            var option = del2.options[i];
            // enable options
            if(choice_social.value == "Twitter"){
                if(!option.value.indexOf("Twitter")){
                    option.style.display = "block";
                }
            }
            if(choice_social.value == "FaceBook"){
                if(!option.value.indexOf("FaceBook")){
                    option.style.display = "block";
                }
            }
            if(choice_social.value == "Instagram"){
                if(!option.value.indexOf("Instagram")){
                    option.style.display = "block";
                }
            }
            if(choice_social.value == "LinkedIn"){
                if(!option.value.indexOf("LinkedIn")){
                    option.style.display = "block";
                }
            }
            if(choice_social.value == "Google"){
                if(!option.value.indexOf("Google")){
                    option.style.display = "block";
                }
            }
        }
    });

    // add to group
    function Add_to_group(selects,select_to_groups) {
        //get length of all selected elements
        var count = [];
        for (var i = 0; i < selects.options.length; i++) {
            var option = selects.options[i];
            if(option.selected == true){
                count.push(option);
            }
        }
        // add all selected elements to group
        for(var j =0; j < count.length; j++) {
            var options = document.createElement("option");
            options = count[j];
            if(count[j].text == "group"){
                count[j].text ="group";
            }else{
                count[j].text = count[j].value;
            }
            select_to_groups.add(options);
            //console.log(options.index);
            count.sort();
        }
        //sort
        sortSelect($("#alter_json"), 'text', 'asc');
        var usedNames = {};
        $("select[name='alter_json'] > option").each(function () {
            if(usedNames[this.text]) {
                $(this).remove();
            } else {
                usedNames[this.text] = this.value;
            }
        });
    }

    /*
     * There we are delete and sort selected
     */

    function delete_from_group(selects,Select_from_db,dels,ids) {
        //get length of all selected elements
        var count = [];
        for (var i = 0; i < selects.options.length; i++) {
            var option = selects.options[i];
            if(option.selected == true){
                count.push(option);
            }
        }
        // add all selected elements to group
        for(var j =0; j < count.length; j++) {
            var options = document.createElement("option");
            options = count[j];
            if(count[j].text == "group"){
                count[j].text ="group";
            }else{
                count[j].text = count[j].value;
            }
            if(option.value.indexOf("Group") != -1){
                option.remove(option.selectedIndex);
            }
            else{
                dels.add(options);
            }
            count.sort();
        }

        //sort
        sortSelect(Select_from_db, 'text', 'asc');
        var usedNames = {};
        $("select[name='Select_from_db2'] > option").each(function () {
            if(usedNames[this.text]) {
                $(this).remove();
            } else {
                usedNames[this.text] = this.value;
            }
        });
    }

    // sort selected
    var sortSelect = function (select, attr, order) {
        if(attr === 'text'){
            if(order === 'asc'){
                $(select).html($(select).children('option').sort(function (x, y) {
                    return $(x).val().toUpperCase() < $(y).val().toUpperCase() ? -1 : 1;
                }));
                $(select).get(0).selectedIndex = 0;
                //e.preventDefault();
            }// end asc
            if(order === 'desc'){
                $(select).html($(select).children('option').sort(function (y, x) {
                    return $(x).val().toUpperCase() < $(y).val().toUpperCase() ? -1 : 1;
                }));
                $(select).get(0).selectedIndex = 0;
                //e.preventDefault();
            }// end desc
        }
    };

    //parsing our put and send

    function parsing() {
        var json_key = [];
        for (var i = 0; i < delet.options.length; i++) {
            var options = delet.options[i];

            /*
             * Here parsing option value;
             */
            // get key value
            var str_key = options.value.split("\\\\");
            var buff_key = str_key[0];

            //delete name from str
            var str = options.value.split("Name: ");
            var string_buff = str[1];
            //console.log(string_buff);

            // get name value
            var name_buff = string_buff.substring(0, string_buff.indexOf(' ID'));
            if (buff_key == 'Twitter') {
                name_buff = string_buff;
            }

            // get id value
            var id = string_buff.split("ID: ");
            var id_buff = id[1];
            id = id_buff;

            //add and convert array to json
            json_key.push({"key": buff_key, "name": name_buff, "id": id_buff});
        }
        console.log(JSON.stringify(json_key));
        var group_name = $("#group_name").val();

        /*
         * send file to db
         */

        $.ajax({
            url: '/cross-sharing-creat_group',
            type: 'GET',
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            dataType: 'html',
            data: {param1: JSON.stringify(json_key),group_name:group_name}
        })
            .done(function(data) {
                console.log("success");
            })
            .fail(function(data) {
                console.log("error");
                console.log(data);
            })
            .success(function(data) {
                $("#alter").append($("<option></option>").attr("value",data).text(group_name));
                //$("#alter_json").append($("<option></option>").attr("value",data).text(JSON.stringify(json_key)));
                var $options = $("#select_to_group > option").clone();
                $('#alter_json').append($options);
                $('#alter_json').append($options);
                // then we do reload
            })
            .always(function(data) {
                console.log("complete");
            })
    }
    //end parsing and send

    function send(){
        var alter = $("#alter option:selected").val();

        if(alter != "") {
            //console.log(alter);
            $.ajax({
                url: '/cross-sharing-select_groups',
                type: 'GET',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                dataType: 'html',
                data: {alters: alter}
            })
                .done(function(data) {
                    console.log("success");
                })
                .fail(function(data) {
                    console.log("error");
                    console.log(data);
                })
                .success(function(data) {

                    var x = document.createElement("OPTION");
                    x.setAttribute("value", "Group\\\\"+data);
                    var t = document.createTextNode("Group\\\\"+data);
                    x.appendChild(t);
                    document.getElementById("alter_json").appendChild(x);

                        var usedNames = {};
                        $("select[name='alter_json'] > option").each(function () {
                            if(usedNames[this.text]) {
                                $(this).remove();
                            } else {
                                usedNames[this.text] = this.value;
                            }
                        });
                })
                .always(function(data) {
                    console.log("complete");
                })
        }
    }

    function sendNow() {
        //var content = $("#summernote").val();
        var content =  $('#summernote').summernote('code');
        console.log(content);

        var json_key = [];
        for (var i = 0; i < alter_json.options.length; i++) {
            var options = alter_json.options[i];

            /*
             * Here parsing option value;
             */

            // get key value
            var str_key = options.value.split("\\\\");
            var buff_key = str_key[0];
            buff_key = buff_key.replace(/\n|\r/g,'');

            //delete name from str
            var str = options.value.split("Name: ");
            var string_buff = str[1];

            var name_buff;
            if(buff_key != "Group") {
                // get name value
                name_buff = string_buff.substring(0, string_buff.indexOf(' ID'));
                if (buff_key == 'Twitter') {
                    name_buff = string_buff;
                }
            }
            else if(buff_key == "Group"){
                str_key = str_key[1].replace(/\n|\r/g,'');
                name_buff = str_key;
            }

            var id_buff;
            if(buff_key != "Group") {
                // get id value
                var id = string_buff.split("ID: ");
                id_buff = id[1];
                id = id_buff;
            }
            else if(buff_key == "Group"){
                id_buff = null;
            }
            //add and convert array to json
            json_key.push({"key": buff_key, "name": name_buff, "id": id_buff});
        }
        //console.log(JSON.stringify(json_key));

        var CrossSharingNow = JSON.stringify(json_key);

        console.log(CrossSharingNow);

        $.ajax({
            url: '/cross-sharing-crossSharingNow',
            type: 'POST',
            headers: {
                'X-CSRF-TOKEN': $('input[name="_token"]').attr('value')
            },
//            dataType: 'html',
            dataType: 'text',
            data: {CrossSharingNow: CrossSharingNow, cs_content:content, img_data_twitter : images_twitter, img_data: images, key:single() }
        })
            .done(function(data) {
                console.log("success");
            })
            .fail(function(data, request, error) {
                console.log(error);
            })
            .success(function(data) {
                console.log(data);
            })
            .always(function(data) {
                console.log("complete");
            })

    }


</script>

